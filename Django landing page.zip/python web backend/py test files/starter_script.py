''''
class test():   
    x = 4
    y =8
    z = x ** y

a = test()
print(a.z)
'''
'''
class Person:
    def __init__(self, name,degree,age):
        self.name = name
        self.degree = degree
        self.age = age

name = input('Enter your name:')
degree = input('Enter your degree:')  
age = input('Enter your age: ')

b = Person(name,degree,age)
print(b.name)
print(b.degree)
print(b.age) 
'''
#simple login system
'''
print('create an account')
username = input('Enter user name: ')
password = input('Enter your password: ')

print('your account has been successfully created')
print('login in')

username2 = input('Enter user name: ')
password2 = input('Enter password: ')

if username == username2 and  password == password2:
    print('logged in')
else:
    print('invalid username or password')
'''
#modules
import test

test.say_hi()