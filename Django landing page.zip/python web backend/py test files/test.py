def say_hi():
    name = input('enter your name: ')
    print('hi ' +name)

say_hi()
