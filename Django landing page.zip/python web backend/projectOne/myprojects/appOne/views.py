from django.shortcuts import render
from django.http import HttpResponse
from .models import Feature
# Create your views here.
def index(request):
    feature1 = Feature()
    feature1.id = 1
    feature1.name = 'basic'
    feature1.details = 'basic setup, free for one month and tier 1 detection'

    feature2 = Feature()
    feature2.id = 2
    feature2.name = 'freelancer'
    feature2.details = 'moderate setup, 50 GB free storage and tier 2 detection'

    feature3 = Feature()
    feature3.id = 3
    feature3.name = 'corporate'
    feature3.details = 'advanced setup, 150 GB free storage and tier 3 detection'

    return render(
        request, 'index.html', {
        'feature1': feature1, 
        'feature2':feature2,
        'feature3': feature3
    })

def counter(request):
    lyrics = request.POST.get('lyrics', False)
    no_of_words = len(lyrics.split())
    return render(request,'counter.html', {'word_count': no_of_words})